# Contributing:

If you would like to contribute, simply fork it. After forking the component and cloning locally you will need to install Grunt with dependencies. Simply run two commands:

```
npm install grunt;
npm install;
```

Now you can start making changes (plugin source in `/src` folder). For create a build type:

```
grunt;
```

If the build process completes without any errors then you are ready to make a pull request.
