//DATA("歌名","地址","ID");
DATA("You Raise Me Up","http://www.jq22.com/demo/audiojs20161020/jq22com.mp3","1");
DATA("The Glorious Death","http://www.jq22.com/demo/jplayer20160613/jq22com.mp3","2");